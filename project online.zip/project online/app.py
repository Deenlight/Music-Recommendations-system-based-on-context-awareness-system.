from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:password@localhost:5432/certificate'
app.config['UPLOAD_FOLDER'] = 'certificates'
db = SQLAlchemy(app)

# Define the Student model
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True)
    adm_no = db.Column(db.String(50), unique=True)  # Change this to String
    password = db.Column(db.String(255))

    certificates = db.relationship('Certificate', back_populates='student')

# Define the Certificate model
class Certificate(db.Model):
    __tablename__ = 'certificate'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    filename = db.Column(db.String(255), nullable=False)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(50), default='Pending')

    student = db.relationship('Student', back_populates='certificates')

# Define the Verification Officer model
class VerificationOfficer(db.Model):
    __tablename__ = 'verification_officer'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)  # Add the primary key 'id'
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(255), nullable=False, unique=True)
    password = db.Column(db.String(255), nullable=False)

    def __repr__(self):
        return f'<VerificationOfficer {self.name}>'

# Create the database tables
with app.app_context():
    db.create_all()

# Routes
@app.route('/')
def home():
    return render_template('home.html')

# Route for student signup
@app.route('/student_signup', methods=['GET', 'POST'])
def student_signup():
    if request.method == 'POST':
        student_name = request.form.get('student_name')
        student_email = request.form.get('student_email')
        adm_no = request.form.get('adm_no')
        student_password = request.form.get('student_password')

        # Check if all fields are filled
        if not student_name or not student_email or not adm_no or not student_password:
            flash('All fields are required!', 'danger')
            return redirect(url_for('student_signup'))

        # Check if the email or admission number already exists
        existing_student = Student.query.filter(
            (Student.email == student_email) | (Student.adm_no == adm_no)
        ).first()
        if existing_student:
            flash('Student with this email or admission number already exists!', 'danger')
            return redirect(url_for('student_signup'))

        # Hash the password before saving it
        hashed_password = generate_password_hash(student_password)

        # Add the new student to the database
        new_student = Student(
            name=student_name,
            email=student_email,
            adm_no=adm_no,
            password=hashed_password
        )
        db.session.add(new_student)
        db.session.commit()

        flash('Student signed up successfully!', 'success')
        return redirect(url_for('student_login'))  # Redirect to the login page after signup

    return render_template('student_signup.html')

# Route for verification officer signup (only for manual database insertion)
@app.route('/officer_signup', methods=['GET', 'POST'])
def officer_signup():
    if request.method == 'POST':
        officer_name = request.form.get('officer_name')
        officer_email = request.form.get('officer_email')
        officer_password = request.form.get('officer_password')

        # Check if all fields are filled
        if not officer_name or not officer_email or not officer_password:
            flash('All fields are required!', 'danger')
            return redirect(url_for('officer_signup'))

        # Check if the officer email already exists
        existing_officer = VerificationOfficer.query.filter_by(email=officer_email).first()
        if existing_officer:
            flash('An officer with this email already exists!', 'danger')
            return redirect(url_for('officer_signup'))

        # Hash the password before saving it
        hashed_password = generate_password_hash(officer_password)

        # Add the new officer to the database
        new_officer = VerificationOfficer(
            name=officer_name,
            email=officer_email,
            password=hashed_password
        )
        db.session.add(new_officer)
        db.session.commit()

        flash('Verification officer signed up successfully!', 'success')
        return redirect(url_for('login'))  # Redirect to login page after signup

    return render_template('officer_signup.html')

# Route for student login
@app.route('/student_login', methods=['GET', 'POST'])
def student_login():
    if request.method == 'POST':
        adm_no = request.form.get('id_no')
        password = request.form.get('password')

        # Fetch student from the database
        student = Student.query.filter_by(adm_no=adm_no).first()

        if student:
            # Check password
            if check_password_hash(student.password, password):
                # Store login session
                session['student_id'] = student.id
                return redirect(url_for('student_home'))  # Redirect to student home

        flash('Invalid admission number or password.', 'danger')
        return redirect(url_for('student_login'))  # Redirect back to login

    return render_template('student_login.html')

# Route for verification officer login
@app.route('/officer_login', methods=['GET', 'POST'])
def officer_login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        officer = VerificationOfficer.query.filter_by(email=email).first()

        if officer:
            # Compare plain-text password
            if officer.password == password:
                session['officer_id'] = officer.id  # Store officer's ID in session
                session['user_type'] = 'verification_officer'  # Store user type
                return redirect(url_for('officer_dashboard'))
            else:
                flash('Invalid password', 'error')
        else:
            flash('No officer found with that email', 'error')

        return redirect(url_for('officer_login'))

    return render_template('officer_login.html')

# Route for logout
@app.route('/logout')
def logout():
    session.clear()  # Clears all session data
    flash('You have been logged out.')
    return redirect(url_for('login'))  # Redirects to login page

# Route for student home page
@app.route('/student_home')
def student_home():
    if 'student_id' not in session:
        flash('Please log in to access this page.', 'warning')
        return redirect(url_for('student_login'))

    student = Student.query.get(session['student_id'])
    return render_template('student_home.html', student=student)

# Route for verification officer dashboard
@app.route('/officer_dashboard')
def officer_dashboard():
    if 'officer_id' not in session:
        return redirect(url_for('officer_login'))

    officer_id = session['officer_id']
    officer = VerificationOfficer.query.get(officer_id)

    # Fetch all certificates and students
    certificates = Certificate.query.all()  # Fetch all certificates
    students = {cert.student_id: Student.query.get(cert.student_id) for cert in certificates}

    return render_template('officer_dashboard.html', officer=officer, certificates=certificates, students=students)

# Configuration for file uploads
UPLOAD_FOLDER = 'certificates'
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def allowed_file(filename):
    """Check if the file extension is allowed."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Route to upload certificate
@app.route('/upload_certificate', methods=['POST'])
def upload_certificate():
    if 'certificate' not in request.files:
        flash('No file part', 'error')
        return redirect(url_for('student_home'))

    file = request.files['certificate']
    if file.filename == '':
        flash('No selected file', 'error')
        return redirect(url_for('student_home'))

    if file:
        filename = secure_filename(file.filename)
        file_path = os.path.join('certificates', filename)
        file.save(file_path)

        # Get the current logged-in student's ID
        student_id = session.get('student_id')

        # Add certificate details to the database
        new_certificate = Certificate(
            student_id=student_id,
            filename=filename,
            status='Pending'  # Default status for verification
        )
        db.session.add(new_certificate)
        db.session.commit()

        flash('Certificate uploaded successfully', 'success')
        return redirect(url_for('student_home'))

# Route to serve uploaded files
@app.route('/certificates/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# Ensure the app runs in debug mode
if __name__ == "__main__":
    app.run(debug=True)
